open ang TERMINAL  sa VSCode
type:
    "npm start"
Open ang website sa 
    http://localhost:3000
    