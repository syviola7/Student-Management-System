const express = require('express');
const path = require('path');
const mongoose = require('mongoose');
const app = express();
const port = 3000;

app.use(express.json());

// MongoDB connection
mongoose.connect('mongodb://localhost:27017/management_system');

// User schema/model
const userSchema = new mongoose.Schema({
  role: { type: String, enum: ['admin', 'teacher'], required: true },
  email: { type: String, required: true, unique: true },
  password: { type: String, required: true },
});
const User = mongoose.model('User', userSchema);

// Class schema/model
const classSchema = new mongoose.Schema({
  name: { type: String, required: true, unique: true }
});
const Class = mongoose.model('Class', classSchema);

// Student schema/model
const studentSchema = new mongoose.Schema({
  firstname: { type: String, required: true },
  lastname: { type: String, required: true },
  email: { type: String, required: true, unique: true },
  admission: { type: String, required: true, unique: true },
  class: { type: String, required: true },
  dateCreated: { type: Date, default: Date.now }
});
const Student = mongoose.model('Student', studentSchema);

// Additional MongoDB connection for teachers database
const teacherConnection = mongoose.createConnection('mongodb://localhost:27017/teachers_db');

// Teacher schema/model (using separate connection)
const teacherSchema = new mongoose.Schema({
  firstname: { type: String, required: true },
  lastname: { type: String, required: true },
  email: { type: String, required: true, unique: true },
  subject: { type: String, required: true },
  dateCreated: { type: Date, default: Date.now }
});
const Teacher = teacherConnection.model('Teacher', teacherSchema);

// Serve static files (including login.html)
app.use(express.static(__dirname));

// Registration endpoint (for testing/demo purposes)
app.post('/api/register', async (req, res) => {
  const { role, email, password } = req.body;
  if (!role || !email || !password) return res.status(400).json({ message: 'All fields required' });
  try {
    const exists = await User.findOne({ email });
    if (exists) return res.status(409).json({ message: 'Email already registered' });
    await User.create({ role, email, password });
    res.status(201).json({ message: 'User registered' });
  } catch (err) {
    res.status(500).json({ message: 'Registration failed' });
  }
});

// Login endpoint
app.post('/api/login', async (req, res) => {
  const { role, email, password } = req.body;
  if (!role || !email || !password) return res.status(400).json({ message: 'All fields required' });
  try {
    const user = await User.findOne({ role, email, password });
    if (!user) return res.status(401).json({ message: 'Invalid credentials' });
    res.json({ message: 'Login successful', role: user.role });
  } catch (err) {
    res.status(500).json({ message: 'Login failed' });
  }
});

// Root route serves login.html
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'login.html'));
});

// Students API

// Get all students
app.get('/api/students', async (req, res) => {
  try {
    const students = await Student.find();
    res.json(students);
  } catch (err) {
    res.status(500).json({ message: 'Failed to fetch students' });
  }
});

// Get a student by ID
app.get('/api/students/:id', async (req, res) => {
  try {
    const student = await Student.findById(req.params.id);
    if (!student) return res.status(404).json({ message: 'Student not found' });
    res.json(student);
  } catch (err) {
    res.status(500).json({ message: 'Failed to fetch student' });
  }
});

// Add a new student
app.post('/api/students', async (req, res) => {
  const { firstname, lastname, email, admission, class: className } = req.body;
  if (!firstname || !lastname || !email || !admission || !className) {
    return res.status(400).json({ message: 'All fields required' });
  }
  try {
    const exists = await Student.findOne({ $or: [{ email }, { admission }] });
    if (exists) return res.status(409).json({ message: 'Student already exists' });
    const student = await Student.create({ firstname, lastname, email, admission, class: className });
    res.status(201).json(student);
  } catch (err) {
    res.status(500).json({ message: 'Failed to add student' });
  }
});

// Update a student
app.put('/api/students/:id', async (req, res) => {
  try {
    const student = await Student.findById(req.params.id);
    if (!student) return res.status(404).json({ message: 'Student not found' });
    const { firstname, lastname, email, admission, class: className } = req.body;
    if (firstname) student.firstname = firstname;
    if (lastname) student.lastname = lastname;
    if (email) student.email = email;
    if (admission) student.admission = admission;
    if (className) student.class = className;
    await student.save();
    res.json(student);
  } catch (err) {
    res.status(500).json({ message: 'Failed to update student' });
  }
});

// Delete a student
app.delete('/api/students/:id', async (req, res) => {
  try {
    const student = await Student.findByIdAndDelete(req.params.id);
    if (!student) return res.status(404).json({ message: 'Student not found' });
    res.json({ message: 'Student deleted' });
  } catch (err) {
    res.status(500).json({ message: 'Failed to delete student' });
  }
});

// Classes API

// Get all classes
app.get('/api/classes', async (req, res) => {
  try {
    const classes = await Class.find();
    res.json(classes);
  } catch (err) {
    res.status(500).json({ message: 'Failed to fetch classes' });
  }
});

// Get a class by ID
app.get('/api/classes/:id', async (req, res) => {
  try {
    const cls = await Class.findById(req.params.id);
    if (!cls) return res.status(404).json({ message: 'Class not found' });
    res.json(cls);
  } catch (err) {
    res.status(500).json({ message: 'Failed to fetch class' });
  }
});

// Add a new class
app.post('/api/classes', async (req, res) => {
  const { name } = req.body;
  if (!name) return res.status(400).json({ message: 'Class name required' });
  try {
    const exists = await Class.findOne({ name });
    if (exists) return res.status(409).json({ message: 'Class already exists' });
    const newClass = await Class.create({ name });
    res.status(201).json(newClass);
  } catch (err) {
    res.status(500).json({ message: 'Failed to create class' });
  }
});

// Update a class
app.put('/api/classes/:id', async (req, res) => {
  const { name } = req.body;
  try {
    const cls = await Class.findById(req.params.id);
    if (!cls) return res.status(404).json({ message: 'Class not found' });
    if (name) cls.name = name;
    await cls.save();
    res.json(cls);
  } catch (err) {
    res.status(500).json({ message: 'Failed to update class' });
  }
});

// Delete a class
app.delete('/api/classes/:id', async (req, res) => {
  try {
    const cls = await Class.findByIdAndDelete(req.params.id);
    if (!cls) return res.status(404).json({ message: 'Class not found' });
    res.json({ message: 'Class deleted' });
  } catch (err) {
    res.status(500).json({ message: 'Failed to delete class' });
  }
});

// Teachers API

// Get all teachers
app.get('/api/teachers', async (req, res) => {
  try {
    const teachers = await Teacher.find();
    res.json(teachers);
  } catch (err) {
    res.status(500).json({ message: 'Failed to fetch teachers' });
  }
});

// Get a teacher by ID
app.get('/api/teachers/:id', async (req, res) => {
  try {
    const teacher = await Teacher.findById(req.params.id);
    if (!teacher) return res.status(404).json({ message: 'Teacher not found' });
    res.json(teacher);
  } catch (err) {
    res.status(500).json({ message: 'Failed to fetch teacher' });
  }
});

// Add a new teacher
app.post('/api/teachers', async (req, res) => {
  const { firstname, lastname, email, subject } = req.body;
  if (!firstname || !lastname || !email || !subject) {
    return res.status(400).json({ message: 'All fields required' });
  }
  try {
    const exists = await Teacher.findOne({ email });
    if (exists) return res.status(409).json({ message: 'Teacher already exists' });
    const teacher = await Teacher.create({ firstname, lastname, email, subject });
    res.status(201).json(teacher);
  } catch (err) {
    res.status(500).json({ message: 'Failed to add teacher' });
  }
});

// Update a teacher
app.put('/api/teachers/:id', async (req, res) => {
  try {
    const teacher = await Teacher.findById(req.params.id);
    if (!teacher) return res.status(404).json({ message: 'Teacher not found' });
    const { firstname, lastname, email, subject } = req.body;
    if (firstname) teacher.firstname = firstname;
    if (lastname) teacher.lastname = lastname;
    if (email) teacher.email = email;
    if (subject) teacher.subject = subject;
    await teacher.save();
    res.json(teacher);
  } catch (err) {
    res.status(500).json({ message: 'Failed to update teacher' });
  }
});

// Delete a teacher
app.delete('/api/teachers/:id', async (req, res) => {
  try {
    const teacher = await Teacher.findByIdAndDelete(req.params.id);
    if (!teacher) return res.status(404).json({ message: 'Teacher not found' });
    res.json({ message: 'Teacher deleted' });
  } catch (err) {
    res.status(500).json({ message: 'Failed to delete teacher' });
  }
});

app.listen(port, () => {
  console.log(`Server running on http://localhost:${port}`);
});
