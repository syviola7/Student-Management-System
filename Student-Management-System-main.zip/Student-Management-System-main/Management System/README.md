install sa ang required dependencies:
npm install

daun open ang terminal:
node server.js

Open browser:

Para ma acess nmo ang classes.html ug teachers.html ka ng naa sa ubos moy link.
http://localhost:5000/classes-page for classes.html
http://localhost:5000/teachers-page for teachers.html