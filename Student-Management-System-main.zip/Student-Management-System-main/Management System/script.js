function toggleSidebar() {
    document.getElementById('sidebar').classList.toggle('active');
  }
  
  function navigateTo(page) {
    window.location.href = page;
  }
  