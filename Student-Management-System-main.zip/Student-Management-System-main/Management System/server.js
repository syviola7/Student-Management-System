const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const cors = require('cors');
const path = require('path');

const app = express();
const PORT = 5000;

// Middleware
app.use(bodyParser.json());
app.use(cors());
app.use(express.static(path.join(__dirname)));

// MongoDB Connection
mongoose.connect('mongodb://localhost:27017/student-management', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});
const db = mongoose.connection;
db.on('error', console.error.bind(console, 'Connection error:'));
db.once('open', () => {
  console.log('Connected to MongoDB');
});

// Schemas and Models
const ClassSchema = new mongoose.Schema({ name: String });
const TeacherSchema = new mongoose.Schema({
  firstname: String,
  lastname: String,
  email: String,
  phone: String,
  class: String,
  dateCreated: { type: Date, default: Date.now },
});

const Class = mongoose.model('Class', ClassSchema);
const Teacher = mongoose.model('Teacher', TeacherSchema);

// Routes
app.get('/classes', async (req, res) => {
  const classes = await Class.find();
  res.json(classes);
});

app.post('/classes', async (req, res) => {
  const newClass = new Class(req.body);
  await newClass.save();
  res.json(newClass);
});

app.get('/teachers', async (req, res) => {
  const teachers = await Teacher.find();
  res.json(teachers);
});

app.post('/teachers', async (req, res) => {
  const newTeacher = new Teacher(req.body);
  await newTeacher.save();
  res.json(newTeacher);
});

// Serve classes.html
app.get('/classes-page', (req, res) => {
  res.sendFile(path.join(__dirname, 'classes.html'));
});

// Serve teachers.html
app.get('/teachers-page', (req, res) => {
  res.sendFile(path.join(__dirname, 'teachers.html'));
});

// Start Server
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
